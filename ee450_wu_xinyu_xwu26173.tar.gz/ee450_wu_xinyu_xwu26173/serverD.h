#pragma once

#define SERVER_D_PORT 42907
#define NAME_D "D"
#define D_FILE_PATH "./double.txt"