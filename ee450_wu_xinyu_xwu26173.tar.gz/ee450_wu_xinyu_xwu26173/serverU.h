#pragma once

#define SERVER_U_PORT 43907
#define NAME_U "U"
#define U_FILE_PATH "./suite.txt"