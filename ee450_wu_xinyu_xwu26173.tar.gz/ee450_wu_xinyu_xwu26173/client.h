int bootup_C();

int login(int sockfd, char* username,char* pwd);

void send_action(int sockfd, int mode, char* username);

