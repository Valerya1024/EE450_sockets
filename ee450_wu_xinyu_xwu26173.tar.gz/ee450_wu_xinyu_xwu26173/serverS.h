#pragma once

#define SERVER_S_PORT 41907
#define SERVER_M_UDP_PORT 44907
#define NAME_S "S"
#define S_FILE_PATH "./single.txt"